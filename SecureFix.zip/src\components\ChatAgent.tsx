import { useCallback, useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { QUICK_PROMPTS } from '@shared/agentKnowledge'
import { fetchChatHealth, sendChatMessage, type ChatMessage } from '@/services/chatApi'
import './ChatAgent.css'

const STORAGE_KEY = 'securefix-chat'

const GREETING: ChatMessage = {
  id: 'hi',
  role: 'assistant',
  content:
    "Hey! I'm Alex from SecureFix. Got a broken device, need a price, or want us to call you back? I'm here to help.",
  actions: [
    { label: 'Book a repair', route: '/book-repair' },
    { label: 'Send my details', route: 'chat:collect' },
  ],
}

function uid() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
}

function loadMessages(): ChatMessage[] {
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY)
    if (!raw) return [GREETING]
    const parsed = JSON.parse(raw) as ChatMessage[]
    return parsed.length ? parsed : [GREETING]
  } catch {
    return [GREETING]
  }
}

export default function ChatAgent() {
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [aiOn, setAiOn] = useState(false)
  const [messages, setMessages] = useState<ChatMessage[]>(loadMessages)
  const messagesRef = useRef(messages)
  const listRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  messagesRef.current = messages

  useEffect(() => {
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(messages))
  }, [messages])

  useEffect(() => {
    void fetchChatHealth().then((h) => setAiOn(Boolean(h?.ai)))
  }, [])

  useEffect(() => {
    if (open && listRef.current) listRef.current.scrollTop = listRef.current.scrollHeight
  }, [messages, open, loading])

  useEffect(() => {
    if (open) inputRef.current?.focus()
  }, [open])

  const reply = useCallback(async (history: ChatMessage[]) => {
    const turns = history.map(({ role, content }) => ({ role, content }))
    const res = await sendChatMessage(turns)
    setMessages((prev) => [
      ...prev,
      {
        id: uid(),
        role: 'assistant',
        content: res.reply,
        actions: res.actions,
        reference: res.reference,
        leadSubmitted: res.leadSubmitted,
      },
    ])
  }, [])

  const send = useCallback(
    async (text: string) => {
      const trimmed = text.trim()
      if (!trimmed || loading) return

      const userMsg: ChatMessage = { id: uid(), role: 'user', content: trimmed }
      const next = [...messagesRef.current, userMsg]
      setMessages(next)
      setInput('')
      setLoading(true)
      try {
        await reply(next)
      } finally {
        setLoading(false)
      }
    },
    [loading, reply],
  )

  const runAction = useCallback(
    (route: string) => {
      if (route === 'chat:collect') {
        void send('Yes please, I would like you to pass my details to the team')
        return
      }
      if (route.startsWith('/') && !route.startsWith('//')) {
        navigate(route)
        setOpen(false)
        return
      }
      window.open(route, route.startsWith('tel:') ? '_self' : '_blank', 'noopener,noreferrer')
    },
    [navigate, send],
  )

  const clearChat = () => {
    setMessages([GREETING])
    sessionStorage.removeItem(STORAGE_KEY)
  }

  return (
    <div className="chat-agent">
      {open && (
        <div className="chat-panel" role="dialog" aria-label="SecureFix chat">
          <header className="chat-header">
            <div>
              <strong>Alex · SecureFix</strong>
              <span>{aiOn ? 'AI assistant' : 'Customer support'}</span>
            </div>
            <div className="chat-header-actions">
              <button type="button" className="chat-reset" onClick={clearChat} aria-label="New chat">
                ↺
              </button>
              <button type="button" className="chat-close" onClick={() => setOpen(false)} aria-label="Close">
                ✕
              </button>
            </div>
          </header>

          <div className="chat-messages" ref={listRef}>
            {messages.map((msg) => (
              <div key={msg.id} className={`chat-bubble chat-bubble-${msg.role}`}>
                <p>{msg.content}</p>
                {msg.leadSubmitted && msg.reference && (
                  <p className="chat-reference">Ref: {msg.reference}</p>
                )}
                {msg.actions && msg.actions.length > 0 && (
                  <div className="chat-actions">
                    {msg.actions.map((a) => (
                      <button
                        key={`${msg.id}-${a.route}`}
                        type="button"
                        className="chat-action-btn"
                        onClick={() => runAction(a.route)}
                      >
                        {a.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}
            {loading && (
              <div className="chat-bubble chat-bubble-assistant chat-typing">
                <span /><span /><span />
              </div>
            )}
          </div>

          <div className="chat-quick">
            {QUICK_PROMPTS.map((p) => (
              <button
                key={p.label}
                type="button"
                className="chat-quick-btn"
                onClick={() => send(p.prompt)}
                disabled={loading}
              >
                {p.label}
              </button>
            ))}
          </div>

          <form
            className="chat-input-row"
            onSubmit={(e) => {
              e.preventDefault()
              void send(input)
            }}
          >
            <input
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your message..."
              disabled={loading}
            />
            <button type="submit" className="chat-send" disabled={loading || !input.trim()}>
              ↑
            </button>
          </form>
        </div>
      )}

      <button
        type="button"
        className="chat-toggle btn-shiny"
        onClick={() => setOpen((v) => !v)}
        aria-label={open ? 'Close chat' : 'Open chat'}
      >
        {open ? '✕' : '💬'}
      </button>
    </div>
  )
}
