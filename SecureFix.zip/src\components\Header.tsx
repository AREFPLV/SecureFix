import { useState } from 'react'
import { Link } from 'react-router-dom'
import { navLinks, site, BOOKING_ROUTE } from '@/data/content'
import Logo from '@/components/Logo'
import './Header.css'

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <header className="header">
      <div className="container header-inner">
        <Link to="/" className="logo-link">
          <Logo />
        </Link>

        <nav className={`nav ${menuOpen ? 'nav-open' : ''}`}>
          {navLinks.map((link) =>
            link.route ? (
              <Link key={link.label} to={link.route} onClick={() => setMenuOpen(false)}>
                {link.label}
              </Link>
            ) : (
              <a key={link.label} href={link.href} onClick={() => setMenuOpen(false)}>
                {link.label}
              </a>
            ),
          )}
        </nav>

        <div className="header-actions">
          <a href={`tel:${site.phone.replace(/\s/g, '')}`} className="btn btn-secondary btn-shiny header-phone-btn">
            {site.phone}
          </a>
          <Link to={BOOKING_ROUTE} className="btn btn-primary header-cta">
            Book Repair
          </Link>
          <button
            className="menu-toggle"
            aria-label="Toggle menu"
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen(!menuOpen)}
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  )
}
