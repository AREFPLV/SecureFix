import { Link } from 'react-router-dom'
import { BOOKING_ROUTE } from '@/data/content'
import './Business.css'

export default function Business() {
  return (
    <section id="delivery" className="section delivery">
      <div className="container delivery-inner">
        <div className="delivery-content">
          <h2>
            Free Delivery &amp; <span className="accent">Same Day Repair</span>
          </h2>
          <p>
            We come to you. We fix it today. Can&apos;t visit our store? We&apos;ll collect
            your device, repair it with genuine parts, and return it the same day.
          </p>
          <div className="delivery-features">
            <div className="delivery-feature">
              <span>🚚</span>
              <strong>Free Collection &amp; Return</strong>
            </div>
            <div className="delivery-feature">
              <span>🔧</span>
              <strong>Same Day Service</strong>
            </div>
            <div className="delivery-feature">
              <span>📦</span>
              <strong>We Collect • We Repair • We Deliver</strong>
            </div>
          </div>
          <div className="delivery-actions">
            <Link to={BOOKING_ROUTE} className="btn btn-primary">
              Book Online
            </Link>
            <a href="#contact" className="btn btn-secondary">
              Message Us Now
            </a>
          </div>
        </div>
        <div className="delivery-visual">
          <img
            src="/images/delivery-banner.png"
            alt="SecureFix free delivery and same day repair"
            className="delivery-banner"
          />
        </div>
      </div>
    </section>
  )
}
