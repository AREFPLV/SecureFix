import './loadEnv.ts'
import { buildSystemPrompt } from '../shared/agentKnowledge.ts'
import { lookupRepairEstimate } from '../shared/repairCatalog.ts'
import { isLeadComplete } from '../shared/customerLead.ts'
import {
  parseAgentJson,
  trimConversation,
  type ChatResponse,
  type ChatTurn,
} from '../shared/fallbackChat.ts'
import { sendLeadEmail } from './sendLeadEmail.ts'

function apiKey() {
  return process.env.GEMINI_API_KEY
}

function model() {
  return process.env.GEMINI_MODEL ?? 'gemini-2.0-flash'
}

export function geminiReady() {
  const key = apiKey()
  return Boolean(key && key.startsWith('AIza'))
}

export function geminiModel() {
  return model()
}

async function maybeSubmitLead(
  parsed: NonNullable<ReturnType<typeof parseAgentJson>>,
  history: ChatTurn[],
): Promise<ChatResponse> {
  const base: ChatResponse = { reply: parsed.reply, actions: parsed.actions, mode: 'ai' }

  if (!parsed.submitLead || !isLeadComplete(parsed.lead)) return base

  const result = await sendLeadEmail(parsed.lead, history)
  if (result.ok) {
    return {
      ...base,
      reference: result.reference,
      leadSubmitted: true,
      reply: `${parsed.reply}\n\nReference: ${result.reference}. Our team will be in touch soon.`,
    }
  }

  return {
    ...base,
    reply: `${parsed.reply}\n\n(I couldn't email your details just now — please call 07438 083630.)`,
  }
}

export async function chatWithGemini(messages: ChatTurn[]): Promise<ChatResponse> {
  const key = apiKey()
  if (!key) throw new Error('No GEMINI_API_KEY')

  const history = trimConversation(messages)
  const full = history.map((m) => m.content).join(' ')
  const lastUser = [...history].reverse().find((m) => m.role === 'user')?.content ?? ''
  const hint = lookupRepairEstimate(lastUser, full)
  const extra = hint ? `\nLIVE LOOKUP: ${hint.summary}` : ''
  const prompt = buildSystemPrompt(extra)

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model()}:generateContent?key=${key}`

  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: prompt }] },
      contents: history.map((m) => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content }],
      })),
      generationConfig: {
        temperature: 0.85,
        maxOutputTokens: 800,
        responseMimeType: 'application/json',
      },
    }),
  })

  if (!res.ok) {
    throw new Error(`Gemini ${res.status}: ${(await res.text()).slice(0, 200)}`)
  }

  const data = (await res.json()) as {
    candidates?: { content?: { parts?: { text?: string }[] } }[]
  }
  const text = data.candidates?.[0]?.content?.parts?.[0]?.text ?? ''
  const parsed = parseAgentJson(text)
  if (parsed) return maybeSubmitLead(parsed, history)

  return { reply: text || 'Sorry, could you say that again?', mode: 'ai' }
}
