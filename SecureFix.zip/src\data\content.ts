export const BOOKING_ROUTE = '/book-repair'
export const TRADE_IN_ROUTE = '/trade-in'
export const ACCESSORIES_ROUTE = '/accessories'
export const ABOUT_ROUTE = '/about'

export const site = {
  name: 'SecureFix',
  tagline: 'Same day repairs',
  phone: '07438 083630',
  email: 'Info@securefix.uk',
  website: 'SecureFix.uk',
  location: 'London, UK',
  whatsapp: 'https://wa.me/447438083630',
}

export const navLinks = [
  { label: 'Book Repair', href: '#contact', route: BOOKING_ROUTE },
  { label: 'Trade In', href: '#trade-in', route: TRADE_IN_ROUTE },
  { label: 'Contact Us', href: '#contact', route: undefined },
  { label: 'About Us', href: '#about', route: ABOUT_ROUTE },
]

export const serviceCards = [
  {
    icon: '🔧',
    title: 'Repair',
    description: 'Expert phone, tablet & computer repairs with same-day service',
    cta: 'Book Now',
    route: BOOKING_ROUTE,
  },
  {
    icon: '📱',
    title: 'Buy & Sell',
    description: 'New & refurbished phones, computers, tablets & accessories',
    cta: 'Trade-In',
    route: TRADE_IN_ROUTE,
  },
  {
    icon: '🛡️',
    title: 'Protect',
    description: 'Premium cases, screen protectors, and accessories',
    cta: 'Learn More',
    route: ACCESSORIES_ROUTE,
  },
]

export const highlights = [
  {
    icon: '⚡',
    title: 'Same Day Service',
    description: 'Most repairs completed the same day in London',
    cta: 'Book Now',
    route: BOOKING_ROUTE,
  },
  {
    icon: '🚚',
    title: 'Free Collection & Return',
    description: 'We collect, repair and deliver back to you',
    cta: 'Learn More',
    href: '#delivery',
  },
  {
    icon: '🛡️',
    title: '2-Year Warranty',
    description: 'Genuine parts backed by quality you can trust',
    cta: 'Learn More',
    href: '#why-us',
  },
]

export const repairs = [
  {
    icon: '💻',
    title: 'MacBook & Laptop Repair',
    description: 'Logic board, display, battery and more',
    features: ['All Brands', 'Board-Level Repair', 'Same Day Available'],
  },
  {
    icon: '📱',
    title: 'Phone Repair',
    description: 'Screen, battery, charging port and water damage',
    features: ['iPhone & Android', 'Genuine Parts', 'Fast Turnaround'],
  },
  {
    icon: '🎮',
    title: 'Gaming Devices',
    description: 'PS5, Xbox, Nintendo Switch repairs',
    features: ['Console Repair', 'Controller Fix', 'HDMI & Disk Drive'],
  },
  {
    icon: '🖨️',
    title: 'Printer Repair',
    description: 'All brands including inkjet, laser and multifunction',
    features: ['All Brands', 'On-Site Service', 'Affordable Prices'],
  },
  {
    icon: '💾',
    title: 'Data Recovery',
    description: '100% confidential recovery from damaged devices',
    features: ['Confidential', 'Advanced Diagnostics', 'High Success Rate'],
  },
  {
    icon: '🦠',
    title: 'Virus Removal',
    description: 'Malware cleanup and system optimisation',
    features: ['Full Scan', 'System Cleanup', 'Protection Setup'],
  },
  {
    icon: '⬆️',
    title: 'RAM / SSD Upgrade',
    description: 'Speed up your PC or laptop with premium upgrades',
    features: ['Premium Parts', 'Setup Included', 'Performance Boost'],
  },
  {
    icon: '📲',
    title: 'Tablet Repair',
    description: 'iPad, Samsung and Android tablet repairs',
    features: ['Screen Replacement', 'Battery Swap', 'All Models'],
  },
]

export const whyUs = [
  {
    icon: '⚡',
    title: 'Same Day Service',
    description: 'Get your device fixed and back the same day',
  },
  {
    icon: '💰',
    title: 'Affordable Prices',
    description: 'Competitive rates with no hidden fees',
  },
  {
    icon: '🔩',
    title: 'High Quality Parts',
    description: 'Only genuine and premium compatible parts',
  },
  {
    icon: '✅',
    title: 'Warranty Included',
    description: '2-year warranty on repairs for peace of mind',
  },
  {
    icon: '⏱️',
    title: 'Fast Turnaround',
    description: 'Most repairs completed within 45 minutes',
  },
  {
    icon: '🔒',
    title: '100% Confidential',
    description: 'Your data and privacy are always protected',
  },
  {
    icon: '🏆',
    title: '10+ Years Experience',
    description: 'Thousands of successful repairs in London',
  },
  {
    icon: '👨‍🔧',
    title: 'Certified Technicians',
    description: 'Expert professionals you can rely on',
  },
]

export const contactMethods = [
  {
    icon: '📞',
    title: 'Call Us',
    value: site.phone,
    href: `tel:${site.phone.replace(/\s/g, '')}`,
  },
  {
    icon: '💬',
    title: 'WhatsApp',
    value: site.phone,
    href: site.whatsapp,
  },
  {
    icon: '✉️',
    title: 'Email Us',
    value: site.email,
    href: `mailto:${site.email}`,
  },
  {
    icon: '📍',
    title: 'Location',
    value: site.location,
    href: '#contact',
  },
  {
    icon: '🌐',
    title: 'Website',
    value: site.website,
    href: '#contact',
  },
]

export type CustomerReview = {
  name: string
  rating: number
  text: string
  device: string
  date: string
}

/** Template reviews — replace with Google Reviews API feed later */
export const customerReviews: CustomerReview[] = [
  {
    name: 'James M.',
    rating: 5,
    text: 'Cracked iPhone screen fixed in under an hour. Genuine parts and friendly service. Highly recommend SecureFix!',
    device: 'iPhone 14 Pro',
    date: '2 weeks ago',
  },
  {
    name: 'Sarah K.',
    rating: 5,
    text: 'My MacBook was not charging. They diagnosed and replaced the port same day. Very professional and fair price.',
    device: 'MacBook Pro',
    date: '1 month ago',
  },
  {
    name: 'Ahmed R.',
    rating: 5,
    text: 'Used the free collection service. They picked up my PS5, fixed the HDMI port, and returned it the same evening. Brilliant!',
    device: 'PlayStation 5',
    date: '3 weeks ago',
  },
  {
    name: 'Emma L.',
    rating: 5,
    text: 'Samsung battery replacement done while I waited. Phone feels brand new again. Will definitely come back.',
    device: 'Samsung Galaxy S24',
    date: '1 week ago',
  },
]

export const googleReviewsPlaceholder = {
  rating: 5.0,
  totalReviews: 120,
  googleUrl: '#',
}
