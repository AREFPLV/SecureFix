import { Link } from 'react-router-dom'
import { site, BOOKING_ROUTE } from '@/data/content'
import HeroPromo from '@/components/HeroPromo'
import './Hero.css'

export default function Hero() {
  return (
    <section className="hero">
      <div className="hero-bg" />
      <div className="container hero-layout">
        <div className="hero-content">
          <p className="hero-eyebrow">Expert device repair service in London</p>
          <h1>
            <span className="hero-line">Your Phone, Your Data.</span>
            <span className="hero-line accent">Secured &amp; Fixed</span>
          </h1>
          <p className="hero-subtitle">
            Professional repair services you can trust. Same-day service with genuine
            parts and a 2-year warranty.
          </p>
          <div className="hero-actions">
            <Link to={BOOKING_ROUTE} className="btn btn-primary btn-shiny">
              Book Repair Now
            </Link>
            <a
              href={`tel:${site.phone.replace(/\s/g, '')}`}
              className="btn btn-secondary btn-shiny"
            >
              Call {site.phone}
            </a>
          </div>
          <div className="hero-stats">
            <div className="hero-stat">
              <strong>10+</strong>
              <span>Years experience</span>
            </div>
            <div className="hero-stat">
              <strong>Same Day</strong>
              <span>Repair service</span>
            </div>
            <div className="hero-stat">
              <strong>2 Year</strong>
              <span>Warranty included</span>
            </div>
          </div>
        </div>
        <div className="hero-visual">
          <HeroPromo />
        </div>
      </div>
    </section>
  )
}
