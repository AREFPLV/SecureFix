import { Link } from 'react-router-dom'
import { highlights } from '@/data/content'
import './Services.css'

export default function Services() {
  return (
    <section id="services" className="section section-alt">
      <div className="container">
        <h2 className="section-title">
          Why <span className="accent">SecureFix</span>
        </h2>
        <p className="section-subtitle">
          Fast, reliable and trusted repair services across London
        </p>
        <div className="card-grid card-grid-3">
          {highlights.map((item) => (
            <article key={item.title} className="service-card">
              <span className="service-icon">{item.icon}</span>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
              {'route' in item && item.route ? (
                <Link to={item.route} className="service-link">
                  {item.cta} →
                </Link>
              ) : (
                <a href={item.href} className="service-link">
                  {item.cta} →
                </a>
              )}
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
