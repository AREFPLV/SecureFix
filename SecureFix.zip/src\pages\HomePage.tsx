import Header from '@/components/Header'
import Hero from '@/components/Hero'
import ServiceCards from '@/components/ServiceCards'
import Products from '@/components/Products'
import WhyUs from '@/components/WhyUs'
import Business from '@/components/Business'
import Contact from '@/components/Contact'
import Footer from '@/components/Footer'

export default function HomePage() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <ServiceCards />
        <Products />
        <WhyUs />
        <Business />
        <Contact />
      </main>
      <Footer />
    </>
  )
}
