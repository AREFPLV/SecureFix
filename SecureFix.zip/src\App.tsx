import { Routes, Route } from 'react-router-dom'
import ScrollToTop from '@/components/ScrollToTop'
import ChatAgent from '@/components/ChatAgent'
import HomePage from '@/pages/HomePage'
import BookRepair from '@/pages/BookRepair'
import TradeIn from '@/pages/TradeIn'
import AccessoriesShop from '@/pages/AccessoriesShop'
import About from '@/pages/About'

export default function App() {
  return (
    <>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/book-repair" element={<BookRepair />} />
        <Route path="/trade-in" element={<TradeIn />} />
        <Route path="/accessories" element={<AccessoriesShop />} />
        <Route path="/about" element={<About />} />
      </Routes>
      <ChatAgent />
    </>
  )
}
