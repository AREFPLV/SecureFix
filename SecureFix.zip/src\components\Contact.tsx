import { Link } from 'react-router-dom'
import { contactMethods, customerReviews, googleReviewsPlaceholder, BOOKING_ROUTE } from '@/data/content'
import './Contact.css'

function Stars({ rating }: { rating: number }) {
  return (
    <span className="review-stars" aria-label={`${rating} out of 5 stars`}>
      {'★'.repeat(rating)}
      {'☆'.repeat(5 - rating)}
    </span>
  )
}

export default function Contact() {
  return (
    <section id="contact" className="section section-alt">
      <div className="container">
        <h2 className="section-title">
          Get In <span className="accent">Touch</span>
        </h2>
        <p className="section-subtitle">
          Need your device fixed today? Contact SecureFix and get it fixed the same day.
        </p>

        <div className="contact-grid">
          <div className="contact-methods">
            {contactMethods.map((method) => (
              <a
                key={method.title}
                href={method.href}
                className="contact-method"
                {...(method.href.startsWith('http') ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
              >
                <span className="contact-method-icon">{method.icon}</span>
                <div>
                  <strong>{method.title}</strong>
                  <span>{method.value}</span>
                </div>
              </a>
            ))}
          </div>

          <div className="contact-right">
            <div className="contact-form contact-booking-cta">
              <h3>Book Your Repair</h3>
              <p>
                Start your repair booking online. Choose your device, select the issue,
                and we&apos;ll take care of the rest.
              </p>
              <Link to={BOOKING_ROUTE} className="btn btn-primary btn-shiny">
                Book Repair Now
              </Link>
            </div>

            <div className="contact-reviews">
              <div className="contact-reviews-header">
                <div>
                  <h3>Customer Reviews</h3>
                  <div className="contact-reviews-rating">
                    <Stars rating={5} />
                    <strong>{googleReviewsPlaceholder.rating.toFixed(1)}</strong>
                    <span>Google Reviews</span>
                  </div>
                </div>
                <a
                  href={googleReviewsPlaceholder.googleUrl}
                  className="contact-reviews-google"
                  aria-label="View on Google (coming soon)"
                >
                  G
                </a>
              </div>

              <div className="contact-reviews-list">
                {customerReviews.map((review) => (
                  <article key={review.name + review.date} className="review-card">
                    <div className="review-card-top">
                      <div className="review-avatar">{review.name.charAt(0)}</div>
                      <div>
                        <strong>{review.name}</strong>
                        <Stars rating={review.rating} />
                      </div>
                      <span className="review-date">{review.date}</span>
                    </div>
                    <p className="review-text">&ldquo;{review.text}&rdquo;</p>
                    <span className="review-device">{review.device}</span>
                  </article>
                ))}
              </div>

              <p className="contact-reviews-note">Google Reviews integration coming soon</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
