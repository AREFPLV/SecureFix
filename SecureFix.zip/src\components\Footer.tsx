import { Link } from 'react-router-dom'
import { navLinks, site } from '@/data/content'
import Logo from '@/components/Logo'
import './Footer.css'

export default function Footer() {
  const year = new Date().getFullYear()

  return (
    <footer className="footer">
      <div className="container footer-inner">
        <div className="footer-brand">
          <Link to="/" className="footer-logo">
            <Logo />
          </Link>
          <p>Professional phone, laptop &amp; device repairs you can trust in London.</p>
        </div>

        <div className="footer-links">
          <h4>Quick Links</h4>
          <ul>
            {navLinks.map((link) => (
              <li key={link.label}>
                {link.route ? (
                  <Link to={link.route}>{link.label}</Link>
                ) : (
                  <a href={link.href}>{link.label}</a>
                )}
              </li>
            ))}
          </ul>
        </div>

        <div className="footer-contact">
          <h4>Contact</h4>
          <p>
            <a href={`tel:${site.phone.replace(/\s/g, '')}`}>{site.phone}</a>
          </p>
          <p>
            <a href={`mailto:${site.email}`}>{site.email}</a>
          </p>
          <p>{site.location}</p>
        </div>
      </div>

      <div className="footer-bottom">
        <div className="container">
          <p>&copy; {year} {site.name}. All rights reserved.</p>
          <p className="footer-disclaimer">Genuine parts. 2-year warranty. Terms apply.</p>
        </div>
      </div>
    </footer>
  )
}
